﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class dashboard
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.RegistrationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProductToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ClassificationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AccountToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CustomerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TransactionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalesToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CashSalesToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CreditToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BillingToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PaymentToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CollectionsSummaryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CashToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CreditToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CollectiblesSummaryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProductEntrySummaryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.QueryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.IndividualLedgerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CollectablesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CollectionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProductEntriesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RegistrationToolStripMenuItem, Me.TransactionToolStripMenuItem, Me.SalesToolStripMenuItem1, Me.BillingToolStripMenuItem1, Me.PaymentToolStripMenuItem1, Me.QueryToolStripMenuItem, Me.ReportsToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1087, 28)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'RegistrationToolStripMenuItem
        '
        Me.RegistrationToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ProductToolStripMenuItem, Me.ClassificationToolStripMenuItem, Me.AccountToolStripMenuItem, Me.CustomerToolStripMenuItem})
        Me.RegistrationToolStripMenuItem.Name = "RegistrationToolStripMenuItem"
        Me.RegistrationToolStripMenuItem.Size = New System.Drawing.Size(107, 24)
        Me.RegistrationToolStripMenuItem.Text = "Registrations"
        '
        'ProductToolStripMenuItem
        '
        Me.ProductToolStripMenuItem.Name = "ProductToolStripMenuItem"
        Me.ProductToolStripMenuItem.Size = New System.Drawing.Size(165, 24)
        Me.ProductToolStripMenuItem.Text = "Product"
        '
        'ClassificationToolStripMenuItem
        '
        Me.ClassificationToolStripMenuItem.Name = "ClassificationToolStripMenuItem"
        Me.ClassificationToolStripMenuItem.Size = New System.Drawing.Size(165, 24)
        Me.ClassificationToolStripMenuItem.Text = "Classification"
        '
        'AccountToolStripMenuItem
        '
        Me.AccountToolStripMenuItem.Name = "AccountToolStripMenuItem"
        Me.AccountToolStripMenuItem.Size = New System.Drawing.Size(165, 24)
        Me.AccountToolStripMenuItem.Text = "Account"
        '
        'CustomerToolStripMenuItem
        '
        Me.CustomerToolStripMenuItem.Name = "CustomerToolStripMenuItem"
        Me.CustomerToolStripMenuItem.Size = New System.Drawing.Size(165, 24)
        Me.CustomerToolStripMenuItem.Text = "Customer"
        '
        'TransactionToolStripMenuItem
        '
        Me.TransactionToolStripMenuItem.Name = "TransactionToolStripMenuItem"
        Me.TransactionToolStripMenuItem.Size = New System.Drawing.Size(109, 24)
        Me.TransactionToolStripMenuItem.Text = "Product Entry"
        '
        'SalesToolStripMenuItem1
        '
        Me.SalesToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CashSalesToolStripMenuItem1, Me.CreditToolStripMenuItem1})
        Me.SalesToolStripMenuItem1.Name = "SalesToolStripMenuItem1"
        Me.SalesToolStripMenuItem1.Size = New System.Drawing.Size(55, 24)
        Me.SalesToolStripMenuItem1.Text = "Sales"
        '
        'CashSalesToolStripMenuItem1
        '
        Me.CashSalesToolStripMenuItem1.Name = "CashSalesToolStripMenuItem1"
        Me.CashSalesToolStripMenuItem1.Size = New System.Drawing.Size(152, 24)
        Me.CashSalesToolStripMenuItem1.Text = "Cash "
        '
        'CreditToolStripMenuItem1
        '
        Me.CreditToolStripMenuItem1.Name = "CreditToolStripMenuItem1"
        Me.CreditToolStripMenuItem1.Size = New System.Drawing.Size(152, 24)
        Me.CreditToolStripMenuItem1.Text = "Credit"
        '
        'BillingToolStripMenuItem1
        '
        Me.BillingToolStripMenuItem1.Name = "BillingToolStripMenuItem1"
        Me.BillingToolStripMenuItem1.Size = New System.Drawing.Size(63, 24)
        Me.BillingToolStripMenuItem1.Text = "Billing"
        '
        'PaymentToolStripMenuItem1
        '
        Me.PaymentToolStripMenuItem1.Name = "PaymentToolStripMenuItem1"
        Me.PaymentToolStripMenuItem1.Size = New System.Drawing.Size(77, 24)
        Me.PaymentToolStripMenuItem1.Text = "Payment"
        '
        'ReportsToolStripMenuItem
        '
        Me.ReportsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CollectionsSummaryToolStripMenuItem, Me.CollectiblesSummaryToolStripMenuItem, Me.ProductEntrySummaryToolStripMenuItem})
        Me.ReportsToolStripMenuItem.Name = "ReportsToolStripMenuItem"
        Me.ReportsToolStripMenuItem.Size = New System.Drawing.Size(72, 24)
        Me.ReportsToolStripMenuItem.Text = "Reports"
        '
        'CollectionsSummaryToolStripMenuItem
        '
        Me.CollectionsSummaryToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CashToolStripMenuItem, Me.CreditToolStripMenuItem})
        Me.CollectionsSummaryToolStripMenuItem.Name = "CollectionsSummaryToolStripMenuItem"
        Me.CollectionsSummaryToolStripMenuItem.Size = New System.Drawing.Size(232, 24)
        Me.CollectionsSummaryToolStripMenuItem.Text = "Collections Summary"
        '
        'CashToolStripMenuItem
        '
        Me.CashToolStripMenuItem.Name = "CashToolStripMenuItem"
        Me.CashToolStripMenuItem.Size = New System.Drawing.Size(118, 24)
        Me.CashToolStripMenuItem.Text = "Cash"
        '
        'CreditToolStripMenuItem
        '
        Me.CreditToolStripMenuItem.Name = "CreditToolStripMenuItem"
        Me.CreditToolStripMenuItem.Size = New System.Drawing.Size(118, 24)
        Me.CreditToolStripMenuItem.Text = "Credit"
        '
        'CollectiblesSummaryToolStripMenuItem
        '
        Me.CollectiblesSummaryToolStripMenuItem.Name = "CollectiblesSummaryToolStripMenuItem"
        Me.CollectiblesSummaryToolStripMenuItem.Size = New System.Drawing.Size(232, 24)
        Me.CollectiblesSummaryToolStripMenuItem.Text = "Collecibles Summary"
        '
        'ProductEntrySummaryToolStripMenuItem
        '
        Me.ProductEntrySummaryToolStripMenuItem.Name = "ProductEntrySummaryToolStripMenuItem"
        Me.ProductEntrySummaryToolStripMenuItem.Size = New System.Drawing.Size(232, 24)
        Me.ProductEntrySummaryToolStripMenuItem.Text = "Product Entry Summary"
        '
        'QueryToolStripMenuItem
        '
        Me.QueryToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.IndividualLedgerToolStripMenuItem, Me.CollectablesToolStripMenuItem, Me.CollectionsToolStripMenuItem, Me.ProductEntriesToolStripMenuItem})
        Me.QueryToolStripMenuItem.Name = "QueryToolStripMenuItem"
        Me.QueryToolStripMenuItem.Size = New System.Drawing.Size(60, 24)
        Me.QueryToolStripMenuItem.Text = "Query"
        '
        'IndividualLedgerToolStripMenuItem
        '
        Me.IndividualLedgerToolStripMenuItem.Name = "IndividualLedgerToolStripMenuItem"
        Me.IndividualLedgerToolStripMenuItem.Size = New System.Drawing.Size(193, 24)
        Me.IndividualLedgerToolStripMenuItem.Text = "Individual Ledger"
        '
        'CollectablesToolStripMenuItem
        '
        Me.CollectablesToolStripMenuItem.Name = "CollectablesToolStripMenuItem"
        Me.CollectablesToolStripMenuItem.Size = New System.Drawing.Size(193, 24)
        Me.CollectablesToolStripMenuItem.Text = "Collectables"
        '
        'CollectionsToolStripMenuItem
        '
        Me.CollectionsToolStripMenuItem.Name = "CollectionsToolStripMenuItem"
        Me.CollectionsToolStripMenuItem.Size = New System.Drawing.Size(193, 24)
        Me.CollectionsToolStripMenuItem.Text = "Collections"
        '
        'ProductEntriesToolStripMenuItem
        '
        Me.ProductEntriesToolStripMenuItem.Name = "ProductEntriesToolStripMenuItem"
        Me.ProductEntriesToolStripMenuItem.Size = New System.Drawing.Size(193, 24)
        Me.ProductEntriesToolStripMenuItem.Text = "Product Entries"
        '
        'dashboard
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1087, 619)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "dashboard"
        Me.Text = "Dashboard"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents RegistrationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProductToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClassificationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AccountToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransactionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CollectionsSummaryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CollectiblesSummaryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProductEntrySummaryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BillingToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PaymentToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalesToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CashSalesToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreditToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CashToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreditToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents QueryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents IndividualLedgerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CollectablesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CollectionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProductEntriesToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
