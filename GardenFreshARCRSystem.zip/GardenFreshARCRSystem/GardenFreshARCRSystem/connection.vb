﻿Imports MySql.Data.MySqlClient
Public Class connection
    Public Shared con As MySqlConnection = New MySqlConnection("Data Source=localhost;Database=db_garden_fresh_ar_system;User ID=root;Password=;")
End Class
